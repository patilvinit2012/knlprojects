package com.kunal.initiator;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import com.kunal.initiator.model.Initiator;

@Path("/initiatorService")
public interface InitiatorService 
{
	@Path("/votes/{electionId}")
	@GET
	public Initiator sendVote(@PathParam("electionId") String electionId);
	
	/*@Path("/inititevote/{electionid}")
	public void invokeFirstParticipant(@PathParam("electionId") String electionId);*/
	@Path("/performvote/{electionId}")
	@GET
	public Initiator performVote(@PathParam("electionId")String electionId);
}
