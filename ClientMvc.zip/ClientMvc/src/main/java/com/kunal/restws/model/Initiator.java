package com.kunal.restws.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="Initiator")
public class Initiator 
{
	private String electionId;
	private int id;
	private int numOfParticipant;
	private String candidate;
	public String getElectionId() {
		return electionId;
	}
	public void setElectionId(String electionId) {
		this.electionId = electionId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNumOfParticipant() {
		return numOfParticipant;
	}
	public void setNumOfParticipant(int numOfParticipant) {
		this.numOfParticipant = numOfParticipant;
	}
	public String getCandidate() {
		return candidate;
	}
	public void setCandidate(String candidate) {
		this.candidate = candidate;
	}
}
