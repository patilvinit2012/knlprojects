package com.kunal.restws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotingAppParticpant2Application {

	public static void main(String[] args) {
		SpringApplication.run(VotingAppParticpant2Application.class, args);
	}

}
