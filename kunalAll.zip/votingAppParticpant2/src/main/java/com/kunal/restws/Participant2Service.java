package com.kunal.restws;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

import com.kunal.restws.model.Participant2;
@Path("/participant2Service")
public interface Participant2Service 
{
	@Path("/votes/{electionId}")
	@GET
	public Participant2 sendVote(@PathParam("electionId") String electionId);
	
	@Path("/performvote/{electionId}")
	@GET
	public Participant2 performVote(@PathParam("electionId") String electionId);
}
