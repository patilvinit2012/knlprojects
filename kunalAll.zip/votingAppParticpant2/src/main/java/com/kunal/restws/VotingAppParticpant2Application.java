package com.kunal.restws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication
public class VotingAppParticpant2Application extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(VotingAppParticpant2Application.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(VotingAppParticpant2Application.class);
	}
}
