package com.kunal.restws;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;
import com.kunal.restws.model.Participant1;

@Service
public class Participant1ServiceImpl implements Participant1Service {
	List<String> participants = new ArrayList<>();

	@Override
	public Participant1 sendVote(String electionId) {
		Participant1 participant = new Participant1();
		Random random = new Random();
		participants.add("second");
		participants.add("third");
		String mycandidate = participants.get(random.nextInt(participants.size()));
		if (electionId != null) {
			participant.setElectionId(electionId);
		}
		participant.setCandidate(mycandidate);
		participant.setId(1);
		participant.setNumOfParticipant(3);
		/* invokeparticipant(electionId); */
		return participant;
	}

	public void invokeparticipant(String electionId) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client
				.target("http://localhost:8080/voteinitiator/services/initiatorService/performvote/electionId");
		Builder request = target.request();
		Response response = request.get();
		System.out.println("Initiator Ready to Vote:" + response.getStatus());

		WebTarget particpant2target = client
				.target("http://localhost:8082/voteparticipant2/services/participant2Service/performvote/electionId");
		Builder participant2request = particpant2target.request();
		Response participant2response = participant2request.get();
		System.out.println("Participant 2 Ready to Vote:" + participant2response.getStatus());
	}

	@Override
	public Participant1 performVote(String electionId) {
		Participant1 participant1 = new Participant1();
		participant1.setElectionId(electionId);
		participants.add("second");
		participants.add("third");
		Random random = new Random();
		participant1.setCandidate(participants.get(random.nextInt(participants.size())));
		participant1.setId(1);
		return participant1;
	}

}
