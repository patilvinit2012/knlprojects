package com.kunal.restws;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.client.WebClient;

import com.kunal.restws.model.Initiator;
import com.kunal.restws.model.Participant1;
import com.kunal.restws.model.Participant2;

public class VotingClient {

	public static void main(String[] args) {
		String electionId = "E123";
		List<String> chooseInitiator = new ArrayList<>();
		chooseInitiator.add("first");
		chooseInitiator.add("second");
		chooseInitiator.add("third");
		Random random = new Random();
		chooseInitiator.get(random.nextInt(chooseInitiator.size()));
		String selectInitiator = null;
		Client client = ClientBuilder.newClient();
		// Choosing Initiator
		if (chooseInitiator.get(random.nextInt(chooseInitiator.size())).equalsIgnoreCase("first")) {

			WebTarget target = client.target("localhost:8080/demo/services/initiatorService/votes/e123");
			Builder request = target.request();
			/* Response response = request.get(); */

			Initiator initiator = request.get(Initiator.class);

			System.out.println("My Candidate is:" + initiator.getCandidate());
			System.out.println("Election Id:" + initiator.getElectionId());
			System.out.println("Initiator Id:" + initiator.getId());
			System.out.println("Number of participant:" + initiator.getNumOfParticipant());
			selectInitiator = "first";
			System.out.println("paricipant3 is Initiator");
			System.out.println("Initiator vote:" + initiator.getCandidate());

		}

		if (chooseInitiator.get(random.nextInt(chooseInitiator.size())).equalsIgnoreCase("second")) {
			WebTarget targetParticipant1 = client
					.target("http://localhost:8080/votingAppParticpant1/services/participant1Service/votes/E123");
			Builder requestParicipant1 = targetParticipant1.request();
			Participant1 participant1 = requestParicipant1.get(Participant1.class);

			System.out.println("My Candidate is:" + participant1.getCandidate());
			System.out.println("Election Id:" + participant1.getElectionId());
			System.out.println("Initiator Id:" + participant1.getId());
			System.out.println("Number of participant:" + participant1.getNumOfParticipant());
			selectInitiator = "second";
			System.out.println("Participant1 is Initiator");
			System.out.println("Initiator vote:" + participant1.getCandidate());
		}
		if (chooseInitiator.get(random.nextInt(chooseInitiator.size())).equalsIgnoreCase("third")) {
			WebTarget targetParticipant2 = client
					.target("http://localhost:8080/votingAppParticpant2/services/participant2Service/votes/E123");
			Builder requestParicipant2 = targetParticipant2.request();
			Participant2 participant2 = requestParicipant2.get(Participant2.class);

			System.out.println("My Candidate is:" + participant2.getCandidate());
			System.out.println("Election Id:" + participant2.getElectionId());
			System.out.println("Initiator Id:" + participant2.getId());
			System.out.println("Number of participant:" + participant2.getNumOfParticipant());
			selectInitiator = "third";
			System.out.println("Participant2 is Initiator");
			System.out.println("Initiator vote:" + participant2.getCandidate());
		} //
		// choosing initiator finish

		// voting started
		if (selectInitiator.equalsIgnoreCase("first")) {
			WebTarget targetParticipant1 = client
					.target("http://localhost:8080/votingAppParticpant1/services/participant1Service/performvote/E123");
			Builder requestParicipant1 = targetParticipant1.request();
			Participant1 participant1 = requestParicipant1.get(Participant1.class);

			System.out.println("Election Id:" + participant1.getElectionId());

			System.out.println("Participant1 vote is:" + participant1.getCandidate());

			WebTarget targetParticipant2 = client
					.target("http://localhost:8080/votingAppParticpant2/services/participant2Service/performvote/E123");
			Builder requestParicipant2 = targetParticipant2.request();
			Participant2 participant2 = requestParicipant2.get(Participant2.class);

			System.out.println("Election Id:" + participant2.getElectionId());

			System.out.println("Participant2 vote is:" + participant2.getCandidate());
		}
		if (selectInitiator.equalsIgnoreCase("second"))

		{
			WebTarget target = client.target("http://localhost:8080/demo/services/initiatorService/performvote/E123");
			Builder request = target.request();
			Initiator initiator = request.get(Initiator.class);

			System.out.println("Election Id:" + initiator.getElectionId());

			System.out.println("participant3 vote is: " + initiator.getCandidate());

			WebTarget targetParticipant2 = client
					.target("http://localhost:8080/votingAppParticpant2/services/participant2Service/performvote/E123");
			Builder requestParicipant2 = targetParticipant2.request();
			Participant2 participant2 = requestParicipant2.get(Participant2.class);

			System.out.println("Election Id:" + participant2.getElectionId());

			System.out.println("Participant2 vote is:" + participant2.getCandidate());
		}
		if (selectInitiator.equalsIgnoreCase("third")) {
			WebTarget target = client.target("http://localhost:8080/demo/services/initiatorService/performvote/E123");
			Builder request = target.request();
			Initiator initiator = request.get(Initiator.class);

			System.out.println("Election Id:" + initiator.getElectionId());
			System.out.println("participant3 vote is:" + initiator.getCandidate());

			WebTarget targetParticipant1 = client
					.target("http://localhost:8080/votingAppParticpant1/services/participant1Service/performvote/E123");
			Builder requestParicipant1 = targetParticipant1.request();
			Participant1 participant1 = requestParicipant1.get(Participant1.class);

			System.out.println("Election Id:" + participant1.getElectionId());

			System.out.println("Participant1 vote is:" + participant1.getCandidate());
		}

		// voting finished
	}

}
