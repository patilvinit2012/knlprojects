package com.kunal.restws;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;
import com.kunal.restws.model.Participant2;

@Service
public class Participant2ServiceImpl implements Participant2Service {
	List<String> participants = new ArrayList<>();

	@Override
	public Participant2 sendVote(String electionId) {
		Participant2 participant2 = new Participant2();
		Random random = new Random();
		participants.add("second");
		participants.add("first");
		String mycandidate = participants.get(random.nextInt(participants.size()));
		if (electionId != null) {
			participant2.setElectionId(electionId);
		}
		participant2.setCandidate(mycandidate);
		participant2.setId(3);
		participant2.setNumOfParticipant(3);
		/* invokeparticipant(electionId); */
		return participant2;
	}

	public void invokeparticipant(String electionId) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client
				.target("http://localhost:8080/voteinitiator/services/initiatorService/performvote/electionId");
		Builder request = target.request();
		Response response = request.get();
		System.out.println("Initiator Ready to Vote:" + response.getStatus());

		WebTarget particpant1target = client
				.target("http://localhost:8081/voteparticipant1/services/participant1Service/performvote/electionId");
		Builder participant1request = particpant1target.request();
		Response participant1response = participant1request.get();
		System.out.println("Participant 1 Ready to Vote:" + participant1response.getStatus());
	}

	@Override
	public Participant2 performVote(String electionId) {
		Participant2 participant2 = new Participant2();
		participant2.setElectionId(electionId);
		participants.add("second");
		participants.add("first");
		Random random = new Random();
		participant2.setCandidate(participants.get(random.nextInt(participants.size())));
		participant2.setId(3);
		return participant2;
	}

}
