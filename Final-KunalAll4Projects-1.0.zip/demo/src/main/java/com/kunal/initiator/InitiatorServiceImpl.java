package com.kunal.initiator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.springframework.stereotype.Service;

import com.kunal.initiator.model.Initiator;

@Service
public class InitiatorServiceImpl implements InitiatorService {
	List<String> candidates = new ArrayList<>();

	public InitiatorServiceImpl() {

		// initiator.setCandidate(candidate);
		candidates.add("first");
		candidates.add("second");
	}

	@Override
	public Initiator sendVote(String electionId) {
		Initiator initiator = new Initiator();
		Random random = new Random();
		candidates.add("first");
		candidates.add("third");
		String mycandidate = candidates.get(random.nextInt(candidates.size()));
		if (electionId != null) {
			initiator.setElectionId(electionId);
		}
		initiator.setCandidate(mycandidate);
		initiator.setId(2);
		initiator.setNumOfParticipant(3);
		/* invokeparticipant(electionId); */
		return initiator;
	}

	public void invokeparticipant(String electionId) {
		Client client = ClientBuilder.newClient();
		WebTarget target = client
				.target("http://localhost:8081/voteparticipant1/services/participant1Service/performvote/electionId");
		Builder request = target.request();
		Response response = request.get();
		System.out.println("Participant 1 Ready to Vote:" + response.getStatus());

		WebTarget particpant2target = client
				.target("http://localhost:8082/voteparticipant2/services/participant2Service/performvote/electionId");
		Builder participant2request = particpant2target.request();
		Response participant2response = participant2request.get();
		System.out.println("Participant 2 Ready to Vote:" + participant2response.getStatus());

	}

	@Override
	public Initiator performVote(String electionId) {
		Initiator initiator = new Initiator();
		initiator.setElectionId(electionId);
		candidates.add("first");
		candidates.add("third");
		Random random = new Random();
		initiator.setCandidate(candidates.get(random.nextInt(candidates.size())));
		initiator.setId(2);
		return initiator;
	}
}
