package com.kunal.restws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VotingClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(VotingClientApplication.class, args);
	}

}
